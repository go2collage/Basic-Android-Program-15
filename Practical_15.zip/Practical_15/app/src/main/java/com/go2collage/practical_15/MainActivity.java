package com.go2collage.practical_15;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CheckBox ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10;
    private Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // checkbox
        ch1 = findViewById(R.id.chkAndroid);
        ch2 = findViewById(R.id.chkFlutter);
        ch3 = findViewById(R.id.chkC);
        ch4 = findViewById(R.id.chkCpp);
        ch5 = findViewById(R.id.chkHTML);
        ch6 = findViewById(R.id.chkJS);
        ch7 = findViewById(R.id.chkJAVA);
        ch8 = findViewById(R.id.chkPHP);
        ch9 = findViewById(R.id.chkXML);
        ch10 = findViewById(R.id.chkKotlin);

        // btn submit
        submit = findViewById(R.id.btnSubmit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String showSelected = "You Selected: \n";

                if (ch1.isChecked())
                    showSelected += "Android \n";

                if (ch2.isChecked())
                    showSelected += "Flutter \n";

                if (ch3.isChecked())
                    showSelected += "C \n";

                if (ch4.isChecked())
                    showSelected += "C++ \n";

                if (ch5.isChecked())
                    showSelected += "HTML \n";

                if (ch6.isChecked())
                    showSelected += "JavaScript \n";

                if (ch7.isChecked())
                    showSelected += "JAVA \n";

                if (ch8.isChecked())
                    showSelected += "PHP \n";

                if (ch9.isChecked())
                    showSelected += "XML \n";

                if (ch10.isChecked())
                    showSelected += "Kotlin \n";

                Toast.makeText(MainActivity.this, showSelected, Toast.LENGTH_SHORT).show();

            }
        });

    }
}